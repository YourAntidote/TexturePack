	"textures/blocks/grass/79c05a", - FOREST
        "textures/blocks/grass/8ab689", - TAIGA
        "textures/blocks/grass/bfb755", - SAVANNA, DESERT
        "textures/blocks/grass/59c93c", - JUNGLE
        "textures/blocks/grass/55c93f", - JUNGLE
        "textures/blocks/grass/88bb66", - BIRCH FOREST
        "textures/blocks/grass/86b87f", - TAIGA, EXTREME HILLS
        "textures/blocks/grass/64c73f", - RAIN FOREST, DARK FOREST
        "textures/blocks/grass/86b783", - TAIGA, EXTREME HILLS
        "textures/blocks/grass/83b593",
        "textures/blocks/grass/80b497",
        "textures/blocks/grass/91bd59", - ISLAND, PLAINS
        "textures/blocks/grass/90814d", - BADLANDS
        "textures/blocks/grass/8eb971", - TAIGA
        "textures/blocks/grass/6a7039", - SWAMP
        "textures/blocks/grass/507a32", - SWAMP

